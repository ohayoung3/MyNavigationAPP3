package com.jeiu.mynavigationapp

import android.os.Bundle
import android.view.View
import androidx.fragment.app.Fragment
import androidx.navigation.fragment.findNavController
import com.jeiu.mynavigationapp.databinding.FragmentCartBinding

class CartFragment : Fragment(R.layout.fragment_cart) {
    private var _binding: FragmentCartBinding? = null
    private val binding get() = _binding!!

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        _binding = FragmentCartBinding.bind(view)

        val menuName = arguments?.getString("menuName") ?: "선택 없음"
        val price = arguments?.getInt("price") ?: 0

        binding.tvCartMenu.text = "메뉴: $menuName"
        binding.tvCartPrice.text = "가격: ${price}원"
        binding.tvTotalPrice.text = "총 금액: ${price}원"

        binding.btnOrder.setOnClickListener {
            findNavController().navigate(R.id.action_cartFragment_to_orderCompleteFragment)
        }
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}