package com.jeiu.mynavigationapp

import android.os.Bundle
import android.view.View
import androidx.core.os.bundleOf
import androidx.fragment.app.Fragment
import androidx.navigation.fragment.findNavController
import com.jeiu.mynavigationapp.databinding.FragmentMenuBinding

class MenuFragment : Fragment(R.layout.fragment_menu) {
    private var _binding: FragmentMenuBinding? = null
    private val binding get() = _binding!!

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        _binding = FragmentMenuBinding.bind(view)

        fun navigateToDetail(menuName: String, price: Int) {
            val bundle = bundleOf(
                "menuName" to menuName,
                "price" to price
            )
            findNavController().navigate(R.id.action_menuFragment_to_detailFragment, bundle)
        }

        binding.btnMenu1.setOnClickListener { navigateToDetail("아메리카노", 3500) }
        binding.btnMenu2.setOnClickListener { navigateToDetail("카페라떼", 4000) }
        binding.btnMenu3.setOnClickListener { navigateToDetail("바닐라라떼", 4500) }
        binding.btnMenu4.setOnClickListener { navigateToDetail("딸기라떼", 5000) }
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}