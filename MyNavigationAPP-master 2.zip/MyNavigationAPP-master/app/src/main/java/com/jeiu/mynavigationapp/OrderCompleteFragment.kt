package com.jeiu.mynavigationapp

import android.os.Bundle
import android.view.View
import androidx.fragment.app.Fragment
import androidx.navigation.fragment.findNavController
import com.jeiu.mynavigationapp.databinding.FragmentOrderCompleteBinding

class OrderCompleteFragment : Fragment(R.layout.fragment_order_complete) {
    private var _binding: FragmentOrderCompleteBinding? = null
    private val binding get() = _binding!!

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        _binding = FragmentOrderCompleteBinding.bind(view)

        binding.btnGoHome.setOnClickListener {
            findNavController().navigate(R.id.action_orderCompleteFragment_to_homeFragment)
        }
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}