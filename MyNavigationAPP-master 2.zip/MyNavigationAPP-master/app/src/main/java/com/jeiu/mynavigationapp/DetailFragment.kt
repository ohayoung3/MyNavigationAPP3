package com.jeiu.mynavigationapp

import android.os.Bundle
import android.view.View
import androidx.core.os.bundleOf
import androidx.fragment.app.Fragment
import androidx.navigation.fragment.findNavController
import com.jeiu.mynavigationapp.databinding.FragmentDetailBinding

class DetailFragment : Fragment(R.layout.fragment_detail) {
    private var _binding: FragmentDetailBinding? = null
    private val binding get() = _binding!!

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        _binding = FragmentDetailBinding.bind(view)

        val menuName = arguments?.getString("menuName") ?: "선택 없음"
        val price = arguments?.getInt("price") ?: 0

        binding.tvMenuName.text = "선택 메뉴: $menuName"
        binding.tvPrice.text = "가격: ${price}원"

        binding.btnAddToCart.setOnClickListener {
            val bundle = bundleOf(
                "menuName" to menuName,
                "price" to price
            )
            findNavController().navigate(R.id.action_detailFragment_to_cartFragment, bundle)
        }
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}